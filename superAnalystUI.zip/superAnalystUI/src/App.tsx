import React from 'react';
import { Helmet, HelmetProvider } from 'react-helmet-async';
import { MantineProvider } from '@mantine/core';
import { Notifications } from '@mantine/notifications';
import { BrowserRouter } from 'react-router-dom';
import Router from './AppRouter'
import './App.css';
import '@mantine/core/styles.css';
import '@mantine/notifications/styles.css';

const helmetContext = {};
export interface ErrorResponse {
  response: { data: { errorMessage?: string; statusCode?: number } }
  message?: string
}

function App() {
  return (
    <HelmetProvider context={helmetContext}>
      <Helmet>
        <meta charSet='utf-8' />
        {/* <meta httpEquiv="Content-Security-Policy" content="upgrade-insecure-requests" /> */}
        <title>Super Analyst</title>
      </Helmet>
      <BrowserRouter>
        <MantineProvider>
          <Notifications position="top-right" />
          <Router />
        </MantineProvider>
      </BrowserRouter>
    </HelmetProvider>
  );
}

export default App;
