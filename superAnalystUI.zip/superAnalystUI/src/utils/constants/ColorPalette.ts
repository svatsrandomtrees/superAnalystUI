import { MantineTheme } from '@mantine/core'
import { FontTypographyInterface } from './TypographyProperties'
import { BreakPointInterface } from './BreakPoints'
export interface ThemeInterface extends MantineTheme {
  other: {
    primaryColor: string
    secondaryColor: string
    tertiaryColor: string
    warningColor: string
    dangerColor: string
    monochromeColor: string | string[]
    otherColor: string | string[]
    otherColorRGBA: string | string[]
    font: FontTypographyInterface
    breakpoints: BreakPointInterface
    pfizerColor: string
  }
}

export const primaryColor = '#32A752'
export const secondaryColor = '#A0D8AF'
export const tertiaryColor = '#1A7E35'

export const warningColor = '#FBB03B'

export const dangerColor = '#C10840'

export const monochromeColor = [
  '#000000', // 0
  '#292E2A', // 1
  '#5C5C5C', // 2
  '#C0C0C0', // 3
  '#E0E0E0', // 4
  '#EFF1F3', // 5
  '#FFFFFF', // 6
  '#B20B33', // 7
  '#EBF9F1', // 8
  '#A0D8Af', // 9
]

export const pfizerColor = '#0000C9';
export const pfizerColor1 ='#0095FF';

export const otherColor = ['#003647', '#F6935A']
// otherColor Index            0          1

export const otherColorRGBA = ['rgba(239, 241, 243, 0.3)', 'rgba(160, 216, 175, 0.07)']
// otherColorRGBA Index                     0                            1

