export const CONFIGURATIONS = {
	EVENT_LINK: 'https://dc1.pfizer.com/gcc-event-newsfeed?eventId=',
    SMWEB_LINK: 'https://smweb.pfizer.com/Incident.aspx?ID=',
    SMWEBRFC_LINK: 'https://smweb.pfizer.com/RFC.aspx?ID='
    
};