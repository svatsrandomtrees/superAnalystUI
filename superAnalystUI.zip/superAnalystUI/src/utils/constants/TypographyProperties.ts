export interface FontTypographyInterface {
  fontFamily: string
  fontStyle: string
}
export const fontFamily = 'Roboto'
export const fontStyle = 'normal'
