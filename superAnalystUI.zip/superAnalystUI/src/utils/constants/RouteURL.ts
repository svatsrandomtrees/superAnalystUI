export const Route_URL = {
	login: `/`,
	somethingwentwrong: '/something_went_wrong',
	accessdenied: '/access_denied',
	dashboard: '/dashboard',
	triageDetails: '/dashboard/triage_details',
	incidentOverview: '/dashboard/incident'
};