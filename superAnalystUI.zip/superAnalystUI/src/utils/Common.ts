export const getAccount = () => {
  const Account = localStorage.getItem('account') ?? ''
  return Account
}