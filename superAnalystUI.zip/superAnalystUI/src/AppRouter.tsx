import { Routes, Route, Navigate } from 'react-router-dom'
import { lazy, Suspense, useEffect } from 'react'
import Loader from './ui/feedback/Loader'
import { Route_URL } from 'utils/constants/RouteURL'
import isAuthenticate from 'utils/isAuthenticate'

const LoginScreen = lazy(() => import('screens/LoginScreen'))
const UnauthorizedScreen = lazy(() => import('screens/UnauthorizedScreen'))
const DashboardScreen = lazy(() => import('screens/DashboardScreen'))
const TriageDetailsScreen = lazy(() => import('screens/TriageDetailsScreen'))
const IncidentOverviewScreen = lazy(() => import('screens/IncidentInfoScreen'))

const PrivateRoute: React.FC<any> = ({ children }) => {
  if (isAuthenticate()) {
    return children
  }
  return <Navigate to={Route_URL.login} />
}
const PublicRoute: React.FC<any> = ({ children }) => {
  if (!isAuthenticate()) {
    return children
  }
  return <Navigate to={Route_URL.dashboard} />
}

function AppRouter() {
  return (
    <div className='App'>
      <Suspense
        fallback={
          <div
            style={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              height: '100vh',
            }}
          >
            <Loader variant='dots' />
          </div>
        }
      >
        <Routes>
          {/* Private Route */}
          <Route
            path='/dashboard'
            element={
              <PrivateRoute>
                <DashboardScreen />
              </PrivateRoute>
            }
          />
          <Route
            path='/dashboard/triage_details'
            element={
              <PrivateRoute>
                <TriageDetailsScreen />
              </PrivateRoute>
            }
          />
          <Route
            path='/dashboard/incident'
            element={
              <PrivateRoute>
                <IncidentOverviewScreen />
              </PrivateRoute>
            }
          />

          {/* Public Route */}
          <Route
            path='/'
            element={
              <PublicRoute>
                <LoginScreen />
              </PublicRoute>
            }
          />
          <Route
            path='/'
            element={
              <PublicRoute>
                <UnauthorizedScreen />
              </PublicRoute>
            }
          />
        </Routes>
      </Suspense>
    </div>
  )
}

export default AppRouter
