import styled from '@emotion/styled'
import { Container, Title } from '@mantine/core'
import { fontFamily, fontStyle } from 'utils/constants/TypographyProperties'

export const StyleContainer = styled(Container)`
    padding: 5px;
    .pageTitle {
        font: ${fontStyle} 30px ${fontFamily};
        /* letter-spacing: -0.88px; */
        color: #000000;
        opacity: 1;
    }
    .pageSubTitle {
        font: ${fontStyle} 20px ${fontFamily};
        /* letter-spacing: -0.88px; */
        color: #000000;
        opacity: 1;
    }
    .textUserName {
        font: ${fontStyle} 25px ${fontFamily};
        letter-spacing: 0px;
        color: #000000;
    }
    .textname {
        color: #6149CD;
    }
    .textRole {
        font: ${fontStyle} 15px ${fontFamily};
        letter-spacing: 0px;
        color: #000000;
        opacity: 1;
    }
    .tableTitle {
        font: ${fontStyle} bold 22px/30px ${fontFamily};
        letter-spacing: 0px;
        color: #0095FF;
        opacity: 1;
    }
    .tableSubTitle {
        font: ${fontStyle} 16px/30px ${fontFamily};
        letter-spacing: 0px;
        color: #18120F;
        opacity: 1;
    }
    .btnCreate {
        background: #FFD471 0% 0% no-repeat padding-box;
        border-radius: 3px;
        opacity: 1;
        font: ${fontStyle} 16px/69px ${fontFamily};
        letter-spacing: 0px;
        color: #000000;
        opacity: 1;
    }
    .inctable th {
        background: #D8D8D8 0% 0% no-repeat padding-box;
        border: 1px solid #BEBEBE;
        opacity: 1;
        font: ${fontStyle} bold 12px/13px ${fontFamily};
        letter-spacing: 0px;
        color: #000000;
        text-transform: uppercase;
    }
    .paperTbl {
        margin-top: 15px;
        padding: 15px;
        background: #FFFFFF 0% 0% no-repeat padding-box;
        box-shadow: 2px 13px 54px #695F9714;
        border: 1px solid #D4D2D2;
        opacity: 1;
        width: "100%",
        min-height: "100vh"
    }
    .incidentInfo {
        padding: 15px;
        margin-top: 15px;
        background: #F6F6F6 0% 0% no-repeat padding-box;
        box-shadow: 2px 13px 54px #695F9714;
        border: 1px solid #8B8B8B;
        border-radius: 3px;
        opacity: 1;
    }
    .incidentInfo [aria-selected~=true] {
        background: #18C5B6 0% 0% no-repeat padding-box;
        border: 1px solid #8B8B8B;
        border-radius: 5px 5px 0px 0px;
        opacity: 1;
        font: ${fontStyle} ${fontFamily};
        letter-spacing: 0px;
        color: #FFFFFF;
    }
    .incidentInfo [aria-selected~=false] {
        background: #FFFFFF 0% 0% no-repeat padding-box;
        border: 1px solid #8B8B8B;
        border-radius: 5px 5px 0px 0px;
        opacity: 1;
    }
    .tabDetailSection {
        text-align: left;
        font: ${fontStyle} ${fontFamily};
        letter-spacing: -0.55px;
        color: #000000;
    }
    .aiBtn {
        background: #0000C9 0% 0% no-repeat padding-box;
        border-radius: 10px;
        opacity: 1;
        font: ${fontStyle} 20px/69px ${fontFamily};
        letter-spacing: 0px;
        color: #FFFFFF;
        opacity: 1;
    }
    .aiIcon {
        padding-left: 5px;
        background: transparent 0% 0% no-repeat padding-box;
    }
    .AiResultContent {
        text-align: left;
    }
`