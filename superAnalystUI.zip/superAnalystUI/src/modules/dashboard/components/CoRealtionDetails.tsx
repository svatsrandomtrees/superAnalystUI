import { Drawer, Title, Table, Anchor } from '@mantine/core';
import { useEffect, useState } from 'react';
import { StyleContainer } from '../styles/Dashboard.styles';
import { CONFIGURATIONS } from 'utils/constants/configurations';
import CoRelationPlaybookDetails from './CoRelationPlaybookDetails';

const CoRealtionDetails = (props: any) => {
    const { opened, open, close, eventDetails } = props;
    const [selectedRows, setSelectedRows] = useState<number[]>([]);

    const rowsEvents = eventDetails && eventDetails.length > 0 && eventDetails.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
        >
            {/* <Table.Td>{element.id}</Table.Td> */}
            <Table.Td>
                <Anchor href={`${CONFIGURATIONS.EVENT_LINK}${element.event_id}`} target="_blank">{element.event_id}</Anchor>
            </Table.Td>
            <Table.Td>{element.document}</Table.Td>
            <Table.Td>{element.similarity_percentage}</Table.Td>
        </Table.Tr>
    ));

    return (
        <>
            <Drawer.Root offset={8} radius="md" size={800} opened={opened} onClose={close} position='right'>
                <Drawer.Overlay />
                <Drawer.Content>
                <Drawer.Header>
                    <Drawer.Title>
                        <Title order={6}>Event CO-Related Details</Title>
                    </Drawer.Title>
                    <Drawer.CloseButton />
                </Drawer.Header>
                <Drawer.Body>
                    <StyleContainer fluid>
                        <Table striped highlightOnHover withTableBorder withColumnBorders className="inctable">
                            <Table.Thead>
                                <Table.Tr>
                                    {/* <Table.Th>ID</Table.Th> */}
                                    <Table.Th>Event_Id</Table.Th>
                                    <Table.Th>Document</Table.Th>
                                    <Table.Th>Similarity_Percentage</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsEvents}</Table.Tbody>
                        </Table>
                        <CoRelationPlaybookDetails />
                    </StyleContainer>
                </Drawer.Body>
                </Drawer.Content>
            </Drawer.Root>
        </>
    );
}

export default CoRealtionDetails;