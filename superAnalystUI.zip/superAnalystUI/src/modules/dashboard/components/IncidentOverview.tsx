import { useEffect, useState } from "react";
import {
    Paper, Table,
    Anchor, LoadingOverlay,
    Group,
    Stack, Text,
    Image,
    Avatar,
    ScrollArea,
    Select, Accordion,
    Button,
    Tooltip,
    Highlight
} from "@mantine/core";
import { useDisclosure } from '@mantine/hooks';
import { useParams, useSearchParams } from 'react-router-dom';
import { StyleContainer } from "../styles/Dashboard.styles";
import PageHeader from "./PageHeader";
import { Icons } from "assets/images";
import { getCoRelatedAction, getRelatedAction } from "actions/Dashboard";
import reactStringReplace from "react-string-replace";
import { IconInfoCircle } from "@tabler/icons-react";

interface AccordionLabelProps {
    label: string;
    image: string;
    description: string;
}

function AccordionLabel({ label, image, description }: AccordionLabelProps) {
    return (
      <Group wrap="nowrap">
        {/* <Avatar radius="xl" size="lg">
            <IconRobot size={1} />
        </Avatar> */}
        <div>
          <Text>{label}</Text>
          <Text size="sm" c="dimmed" fw={400}>
            {description}
          </Text>
        </div>
      </Group>
    );
}

const regx = /(?=.)(.*)(?<=:)/gim;

const IncidentOverview = () => {
    const [searchParams] = useSearchParams();
    const eventTitle = searchParams.get('eventTitle');
    const eventId = searchParams.get('eventId');
    const [filterSiteValue, setFilterSiteValue] = useState<string | null>('');
    const [selectedRows, setSelectedRows] = useState<number[]>([]);
    const [eventListDetails, setEventListDetails] = useState<any>();

    const [visible, handlers] = useDisclosure(false);

    useEffect(() => {
        handlers.open();
        const response = getRelatedAction({ "input_query": eventTitle, "event_id": eventId, "site": filterSiteValue });
        response.then((result: any) => {
            setEventListDetails(result);
            handlers.close();
        });
    }, [eventTitle, filterSiteValue])

    const rowsSimilarEvents = eventListDetails && eventListDetails.similar_events && eventListDetails.similar_events.length > 0 && eventListDetails.similar_events.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element[0].page_content}</Table.Td>
            <Table.Td>{element[1].toFixed(2)}</Table.Td>
            <Table.Td>{element[0]['metadata'].event_id}</Table.Td>
            <Table.Td>{element[0]['metadata'].issue_source}</Table.Td>
            <Table.Td>{element[0]['metadata'].responsible_service_area}</Table.Td>
            <Table.Td>{element[0]['metadata'].event_status}</Table.Td>
        </Table.Tr>
    ));

    const rowsSimilarIncidents = eventListDetails && eventListDetails.similar_incidents && eventListDetails.similar_incidents.length > 0 && eventListDetails.similar_incidents.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element[0].page_content}</Table.Td>
            <Table.Td>{element[1].toFixed(2)}</Table.Td>
            <Table.Td>{element[0]['metadata'].NUMBERPRGN}</Table.Td>
            <Table.Td>{element[0]['metadata'].STATUS}</Table.Td>
            <Table.Td>{element[0]['metadata'].LOCATION}</Table.Td>
        </Table.Tr>
    ));

    const rowsSimilarRfc = eventListDetails && eventListDetails.similar_rfc && eventListDetails.similar_rfc.length > 0 && eventListDetails.similar_rfc.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element[0].page_content}</Table.Td>
            <Table.Td>{element[1].toFixed(2)}</Table.Td>
            <Table.Td>{element[0]['metadata'].NUMBERPRGN}</Table.Td>
            <Table.Td>{element[0]['metadata'].STATUS}</Table.Td>
            <Table.Td>{element[0]['metadata'].LOCATION}</Table.Td>
        </Table.Tr>
    ));

    const rowsSimilarProblems = eventListDetails && eventListDetails.similar_problems && eventListDetails.similar_problems.length > 0 && eventListDetails.similar_problems.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element[0].page_content}</Table.Td>
            <Table.Td>{element[1].toFixed(2)}</Table.Td>
            <Table.Td>{element[0]['metadata'].ID}</Table.Td>
            <Table.Td>{element[0]['metadata'].STATUS}</Table.Td>
        </Table.Tr>
    ));

    const rowsSimilarProblemTasks = eventListDetails && eventListDetails.similar_pt && eventListDetails.similar_pt.length > 0 && eventListDetails.similar_pt.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element[0].page_content}</Table.Td>
            <Table.Td>{element[1].toFixed(2)}</Table.Td>
            <Table.Td>{element[0]['metadata'].ID}</Table.Td>
            <Table.Td>{element[0]['metadata'].ASSIGNMENT}</Table.Td>
        </Table.Tr>
    ));

    return (
        <StyleContainer fluid>
            <LoadingOverlay loaderProps={{ color: '#000484' }} visible={visible} zIndex={1000} overlayProps={{ radius: "sm", blur: 2, children: 'Loading, Waiting for vox response, it may take up to 1-2 minutes....' }} />
            <PageHeader title={'Event Overview'} subTitle={eventTitle} />
            <Paper className="paperTbl">
                <Group justify="space-between">
                    <Stack
                        align="stretch"
                        justify="center"
                        gap="0"
                    >
                        <Group justify="">
                            <Button variant="default" className="aiBtn">
                                AI Results <Image
                                    className="aiIcon"
                                    src={Icons.Imgbot_white}
                                    onClick={() => { }}
                                />
                            </Button>
                            {/* <Text size="sm">
                                Click for generated resolution steps
                            </Text> */}
                        </Group>
                    </Stack>
                    <Group wrap="nowrap">
                        <Select
                            label=""
                            w={240}
                            placeholder="Site Filter"
                            data={['CHINA BASED - REMOTE USER',
                            'WALTON OAKS',
                            'ZHENG ZHOU',
                            'SANDWICH',
                            'DALIAN AFSS',
                            'PEAPACK',
                            'VENDOR-INDIA - NON PFIZER BASED',
                            'FREIBURG',
                            'BEIJING',
                            'VENDOR-ITALY - NON PFIZER BASED',
                            'GUANGZHOU',
                            'THESSALONIKI EAST PLAZA HUB',
                            'VIENNA',
                            'ZAVENTEM',
                            'NEW YORK',
                            'TOKYO',
                            'GRANGE CASTLE',
                            'MUMBAI',
                            'MADRID',
                            'RIVES DE PARIS',
                            'GOA',
                            'TUAS',
                            'VENDOR-POLAND - NON PFIZER BASED',
                            'RIYADH',
                            'PRAGUE',
                            'ASCOLI',
                            'VIZAG PLANT',
                            'BUCHAREST',
                            'WARSAW',
                            'SOMERSET RDC',
                            'TEL AVIV',
                            'BERLIN',
                            'CHENNAI AAKASH',
                            'DUBLIN GFSS',
                            'PUURS',
                            'CHENNAI ACCENTURE',
                            'WUHAN PGRD',
                            'BUDAPEST',
                            'SAO PAULO WBB',
                            'WUHAN',
                            'CAIRO FESTIVAL CITY',
                            'BANGKOK',
                            'CATANIA',
                            'ISTANBUL LEVENT',
                            'ALGIERS',
                            'SHANGHAI CITIC SQUARE',
                            'THESSALONIKI ZEDA',
                            'NANJING',
                            'CHENNAI EMERALD',
                            'RINGASKIDDY API',
                            'KALAMAZOO',
                            'VENDOR-NETHERLANDS - NON PFIZER BASED',
                            'SANFORD',
                            'SYDNEY',
                            'NEWBRIDGE',
                            'AWS US EAST 1',
                            'SHANGHAI PGRD',
                            'ORTH',
                            'DURHAM RDC',
                            'NEW DELHI RO',
                            'OSLO',
                            'MOSCOW',
                            'VENDOR-BULGARIA - NON PFIZER BASED',
                            'HONG KONG WPO',
                            'JINAN',
                            'VENDOR-SERBIA - NON PFIZER BASED',
                            'GROTON',
                            'AWS EU WEST 1',
                            'SINGAPORE WPO',
                            'ROME',
                            'CHANGSHA WBB',
                            'DUBLIN CITY WEST',
                            'TUAS 2',
                            'MADRID ALGETE',
                            'SEOUL',
                            'VENDOR-ARMENIA - NON PFIZER BASED',
                            'VENDOR-KOREA - NON PFIZER BASED',
                            'JEDDAH PLANT',
                            'DUBAI MEDIA CITY',
                            'ZAGREB PLANT SAVSKI MAROF',
                            'TIANJIN',
                            'VALENCIA (ESP)',
                            'EXTERNAL-US',
                            'ZUG',
                            'VENDOR-CZECH REPUBLIC - NON PFIZER BASED',
                            'VENDOR-CHINA - NON PFIZER BASED',
                            'BANGALORE DIDATA',
                            'KUALA LUMPUR',
                            'JOHANNESBURG',
                            'ATHENS',
                            'AWS AP SOUTHEAST 1',
                            'INDIA BASED - REMOTE USER',
                            'MAKATI CITY',
                            'COLLEGEVILLE',
                            'ESCAZU AVENIDA',
                            'VENDOR-JAPAN - NON PFIZER BASED',
                            'JEDDAH',
                            'STRANGNAS',
                            'KIRKLAND',
                            'SANTIAGO MACUL',
                            'HANGZHOU',
                            'AMER',
                            'JAPAN BASED - REMOTE USER',
                            'TAIPEI',
                            'GLOBAL',
                            'TAKETOYO',
                            'VENDOR-UNITED STATES - NON PFIZER BASED',
                            'VENDOR-GERMANY - NON PFIZER BASED',
                            'VENDOR-SINGAPORE - NON PFIZER BASED',
                            'USA BASED - REMOTE USER',
                            'CHENNAI LAB',
                            'BOTHELL',
                            'STERLING DATA CENTER',
                            'VENDOR-SPAIN - NON PFIZER BASED',
                            'HASSELT',
                            'ANDOVER',
                            'CHENGDU',
                            'LA JOLLA',
                            'LAKE FOREST',
                            'CIBUBUR (JAKARTA-GANDARIA)',
                            'XI AN',
                            'KARACHI S.I.T.E.',
                            'ST. LOUIS BIOPLACE',
                            'EUROPEAN DATA CENTER',
                            'ROCKY MOUNT',
                            'MCPHERSON PLANT',
                            'SAN JOSE VILLAGE HUB',
                            'JAKARTA',
                            'VENDOR-MALAYSIA - NON PFIZER BASED',
                            'MULGRAVE PLANT',
                            'VENDOR-CANADA - NON PFIZER BASED',
                            'NANCHANG',
                            'AWS EU CENTRAL 1',
                            'FUZHOU',
                            'UNKNOWN',
                            'VENDOR-PHILIPPINES - NON PFIZER BASED',
                            'TAMPA HUB',
                            'SAN FRANCISCO OYSTER POINT',
                            'PEARL RIVER',
                            'LOS ARCOS',
                            'TOLUCA',
                            'AUCKLAND',
                            'POMPEYA',
                            'VENDOR-AUSTRALIA - NON PFIZER BASED',
                            'VENDOR-PERU - NON PFIZER BASED',
                            'BOGOTA SUBA',
                            'LIMA',
                            'EL JADIDA',
                            'HELSINKI',
                            'SANTIAGO LAS ARTES',
                            'VENDOR-BRAZIL - NON PFIZER BASED',
                            'PARSIPPANY',
                            'CAMBRIDGE-MA',
                            'QUITO',
                            'MEMPHIS LOGISTICS',
                            'MEMPHIS GFS',
                            'VENDOR-ISRAEL - NON PFIZER BASED',
                            'PANAMA CITY',
                            'PANAMA CITY BMW PLAZA',
                            'PLEASANT PRAIRIE',
                            'BRANDON',
                            'AWS US EAST 2',
                            'VENDOR-MEXICO - NON PFIZER BASED',
                            'ROCHESTER - KING',
                            'LA PLAINE',
                            'MILAN',
                            'VENDOR-UNITED KINGDOM - NON PFIZER BASED',
                            'FRANKLIN',
                            'SILVER SPRING',
                            'NEW HAVEN',
                            'CASABLANCA',
                            'MARLOW',
                            'KARACHI COMMERCIAL',
                            'SARAJEVO',
                            'ZURICH',
                            'BRATISLAVA',
                            'RIO PIEDRAS',
                            'KIEV',
                            'KUNMING',
                            'TUNIS',
                            'CAIRO HEADQUARTERS',
                            'SUZHOU PDB',
                            'KARLSRUHE',
                            'SOFIA',
                            'MIDDLETON',
                            'CAMBRIDGE-UK',
                            'SANFORD NORTH',
                            'ERASME',
                            'SEVILLA',
                            'TUNIS PLANT',
                            'BELGRADE',
                            'MONTEVIDEO',
                            'VENDOR-GREECE - NON PFIZER BASED',
                            'ALGIERS PLANT',
                            'VENDOR-MOROCCO - NON PFIZER BASED',
                            'BALLERUP',
                            'VENDOR-EGYPT - NON PFIZER BASED',
                            'STOCKHOLM',
                            'VENDOR-UKRAINE - NON PFIZER BASED',
                            'VENDOR-IRELAND - NON PFIZER BASED',
                            'ALMATY',
                            'ALICANTE',
                            'KUWAIT CITY',
                            'HANOI',
                            'VENDOR-GEORGIA - NON PFIZER BASED',
                            'CAPELLE AAN DEN IJSSEL',
                            'LAGOS',
                            'VENDOR-TAIWAN - NON PFIZER BASED',
                            'PORTO SALVO',
                            'AWS AP NORTHEAST 1',
                            'WUXI',
                            'TUNIS DISTRIBUTION CENTER',
                            'ZAGREB',
                            'WASHINGTON DC',
                            'VENDOR-HUNGARY - NON PFIZER BASED',
                            'EXTERNAL',
                            'VENDOR-SOUTH AFRICA - NON PFIZER BASED',
                            'DALIAN VSOT',
                            'ITAPEVI',
                            'ALGIERS DC',
                            'VENDOR-LATVIA - NON PFIZER BASED',
                            'HO CHI MINH',
                            'HANGZHOU INNOVATION',
                            'HEFEI',
                            'MELBOURNE COMMERCIAL',
                            'SEOUL QO LAB',
                            'AIG',
                            'BUENOS AIRES THAMES',
                            'VENDOR-COLOMBIA - NON PFIZER BASED',
                            'VENDOR-ARGENTINA - NON PFIZER BASED',
                            'BEIRUT SIN EL FIL',
                            'WEST TRENTON',
                            'BARCELONA',
                            'VENDOR-FRANCE - NON PFIZER BASED',
                            'VENDOR-EL SALVADOR - NON PFIZER BASED',
                            'BOULDER ARRAY',
                            'VENDOR-NIGERIA - NON PFIZER BASED',
                            'HURLEY',
                            'VENDOR-TURKEY - NON PFIZER BASED',
                            'LONDON CRICK INSTITUTE',
                            'VENDOR-FINLAND - NON PFIZER BASED',
                            'SHENZHEN CALL CENTER',
                            'NICOSIA',
                            'AMMAN - WYE',
                            'LJUBLJANA',
                            'SHARJAH',
                            'VILNIUS',
                            'FAISALABAD',
                            'CHONG QING',
                            'SINGAPORE SLS',
                            'MACAU',
                            'LUXEMBOURG',
                            'ICHIGAO',
                            'SINGAPORE KIM CHUAN',
                            'AWS CN NORTH 1',
                            'CAIRO RAMSIS',
                            'KARACHI WAREHOUSE',
                            'APAC',
                            'NARITA CC-1',
                            'VENDOR-BRUNEI - NON PFIZER BASED',
                            'EMEA',
                            'VENDOR-ROMANIA - NON PFIZER BASED',
                            'VENDOR-INDONESIA - NON PFIZER BASED',
                            'VENDOR-THAILAND - NON PFIZER BASED',
                            'VENDOR-SWEDEN - NON PFIZER BASED',
                            'VENDOR-BELGIUM - NON PFIZER BASED',
                            'VENDOR-RUSSIA - NON PFIZER BASED',
                            'VENDOR-HONG KONG - NON PFIZER BASED',
                            'PETACH TIQVA DR',
                            'A',
                            'DOMINICAN REPUBLIC',
                            'GUATEMALA CITY',
                            'VENDOR-SENEGAL - NON PFIZER BASED',
                            'VENDOR-LEBANON - NON PFIZER BASED',
                            'DALIAN HP',
                            'VENDOR-AUSTRIA - NON PFIZER BASED',
                            'VENDOR-DENMARK - NON PFIZER BASED',
                            'VENDOR-SLOVAKIA - NON PFIZER BASED',
                            'BANGALORE BRICKWORK',
                            'VENDOR-GUATEMALA - NON PFIZER BASED',
                            'MERIDIANO',
                            'MISSISSAUGA CONSUMER',
                            'TEGUCIGALPA',
                            'VENDOR-CHILE - NON PFIZER BASED',
                            'MANAMA',
                            'SINGAPORE MTDC',
                            'OTHER',
                            'NAIROBI',
                            'LA CORUNIA',
                            'ISLAMABAD',
                            'LAHORE',
                            'VENDOR-UNITED ARAB EMIRATES - NON PFIZER',
                            'HP DISPATCH SITE',
                            'VENDOR-GHANA - NON PFIZER BASED',
                            'VENDOR-KYRGYZSTAN - NON PFIZER BASED',
                            'VENDOR-SWITZERLAND - NON PFIZER BASED',
                            'BANGALORE INFOSYS',
                            'MURCIA',
                            'SINGAPORE PGS OFFICE',
                            'BILBAO',
                            'NEW YORK CTI',
                            'YOKOHAMA-PC',
                            'VENDOR-ICELAND - NON PFIZER BASED',
                            'VENDOR-NEW ZEALAND - NON PFIZER BASED',
                            'AZURE EAST US 1',
                            'AWS US WEST 2',
                            'CIMANGGIS',
                            'BATTLEBORO DISTRIBUTION',
                            'VENDOR-COSTA RICA - NON PFIZER BASED',
                            'VENDOR-LITHUANIA - NON PFIZER BASED']}
                            defaultValue=""
                            allowDeselect={false}
                            searchable
                            clearable
                            onChange={(value: string | null) => setFilterSiteValue(value)}
                        />
                    </Group>
                </Group>
            </Paper>
            <Accordion chevronPosition="right" variant="contained" pt={10}>
                <Accordion.Item value={'acc_similar_events'}>
                    <Accordion.Control>
                        <AccordionLabel label='Similar Events' image='' description="Similar event's based on Event title" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable"
                            style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}
                        >
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>Event_Title</Table.Th>
                                    <Table.Th>
                                        Similarity_Score
                                        <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Similarity score represents how similar two events are based on their title">
                                            <IconInfoCircle size={20} />
                                        </Tooltip>
                                    </Table.Th>
                                    <Table.Th>Event_ID</Table.Th>
                                    <Table.Th>issue_source</Table.Th>
                                    <Table.Th>Responsible_service_area</Table.Th>
                                    <Table.Th>Event_Status</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsSimilarEvents ? rowsSimilarEvents : 'No record found for the selected event & location'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                        <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                            <ScrollArea h={350}>
                                <Text fw={700}>GCC Notes:</Text>
                                <div style={{ whiteSpace: "pre-line" }}>
                                { eventListDetails && eventListDetails.gcc_notes &&
                                    eventListDetails.gcc_notes
                                }
                                </div>
                            </ScrollArea>
                        </Paper>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_similar_incidents'}>
                    <Accordion.Control>
                        <AccordionLabel label='Similar Incidents' image='' description="Similar Incidents based on Event title and incident description" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>Incident_Breif_Description</Table.Th>
                                    <Table.Th>
                                        Similarity_Score
                                        <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Similarity score represents how similar an incident is based on description and event title">
                                            <IconInfoCircle size={20} />
                                        </Tooltip>
                                    </Table.Th>
                                    <Table.Th>NUMBERPRGN</Table.Th>
                                    <Table.Th>STATUS</Table.Th>
                                    <Table.Th>LOCATION</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsSimilarIncidents ? rowsSimilarIncidents : 'No Record Found for the selected event & location.'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                        <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                            <ScrollArea h={350}>
                                <Text fw={700}>Incident Steps:</Text>
                                <div style={{ whiteSpace: "pre-line" }}>
                                { eventListDetails && eventListDetails.incident_steps &&
                                    eventListDetails.incident_steps
                                }
                                </div>
                            </ScrollArea>
                        </Paper>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_similar_rfc'}>
                    <Accordion.Control>
                        <AccordionLabel label='Similar RFC' image='' description="Similar RFC based on Event title and incident description" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>Incident_Breif_Description</Table.Th>
                                    <Table.Th>
                                        Similarity_Score
                                        <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Similarity score represents how similar an RFC is based on description and event title">
                                            <IconInfoCircle size={20} />
                                        </Tooltip>
                                    </Table.Th>
                                    <Table.Th>NUMBERPRGN</Table.Th>
                                    <Table.Th>STATUS</Table.Th>
                                    <Table.Th>LOCATION</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsSimilarRfc ? rowsSimilarRfc : 'No record found for the selected event & location'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                        <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                            <ScrollArea h={350}>
                                <Text fw={700}>RFC Steps:</Text>
                                <div style={{ whiteSpace: "pre-line" }}>
                                { eventListDetails && eventListDetails.rfc_steps &&
                                    eventListDetails.rfc_steps
                                }
                                </div>
                            </ScrollArea>
                        </Paper>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_similar_problems'}>
                    <Accordion.Control>
                        <AccordionLabel label='Similar Problems' image='' description="Similar problems based on Event title and Problem Description" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>Problem_Breif_Description</Table.Th>
                                    <Table.Th>
                                        Similarity_Score
                                        <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Similarity score represents how similar an problem is based on description and event title">
                                            <IconInfoCircle size={20} />
                                        </Tooltip>
                                    </Table.Th>
                                    <Table.Th>ID</Table.Th>
                                    <Table.Th>STATUS</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsSimilarProblems ? rowsSimilarProblems : 'No record found for the selected event & location'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                        <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                            <ScrollArea h={350}>
                                <Text fw={700}>Problem Data:</Text>
                                <div style={{ whiteSpace: "pre-line" }}>
                                { eventListDetails && eventListDetails.problem_data &&
                                    eventListDetails.problem_data
                                }
                                </div>
                            </ScrollArea>
                        </Paper>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_similar_problems_tasks'}>
                    <Accordion.Control>
                        <AccordionLabel label='Similar Problems Tasks' image='' description="" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder withColumnBorders stickyHeader className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>Problem_task_Breif_Description</Table.Th>
                                    <Table.Th>
                                        Similarity_Score
                                        <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Similarity score represents how similar an problem task is based on description and event title">
                                            <IconInfoCircle size={20} />
                                        </Tooltip>
                                    </Table.Th>
                                    <Table.Th>ID</Table.Th>
                                    <Table.Th>ASSIGNMENT</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsSimilarProblemTasks ? rowsSimilarProblemTasks : 'No record found for the selected event & location'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                        <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                            <ScrollArea h={350}>
                                <Text fw={700}>Problem Task Data:</Text>
                                <div style={{ whiteSpace: "pre-line" }}>
                                { eventListDetails && eventListDetails.problem_task_data &&
                                    eventListDetails.problem_task_data
                                }
                                </div>
                            </ScrollArea>
                        </Paper>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_triage_details'}>
                    <Accordion.Control>
                        <AccordionLabel label='Triage Details' image='' description="" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                            <ScrollArea h={350}>
                                <div style={{ whiteSpace: "pre-line" }}>
                                { eventListDetails && eventListDetails.triage_res &&
                                    eventListDetails.triage_res
                                }
                                </div>
                            </ScrollArea>
                        </Paper>
                    </Accordion.Panel>
                </Accordion.Item>
            </Accordion>
            <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                <ScrollArea h={350}>
                    <Text fw={700}>Overall Runbook:</Text>
                    <div style={{ whiteSpace: "pre-line" }}>
                    { eventListDetails && eventListDetails.overall_runbook &&
                        reactStringReplace(eventListDetails.overall_runbook, regx, (match: any, i) => (
                            <strong>
                                {match}
                            </strong>
                        ))
                    }
                    </div>
                </ScrollArea>
            </Paper>
        </StyleContainer>
    )
}

export default IncidentOverview;