import { useEffect, useState } from "react";
import {
    Paper, Table,
    Anchor, LoadingOverlay,
    Group,
    Stack, Text,
    Image,
    Avatar,
    ScrollArea,
    Select, Accordion,
    Button,
    Tooltip,
    Highlight,
    Input
} from "@mantine/core";
import { useDisclosure } from '@mantine/hooks';
import { useParams, useSearchParams } from 'react-router-dom';
import { StyleContainer } from "../styles/Dashboard.styles";
import PageHeader from "./PageHeader";
import { Icons } from "assets/images";
import { getTriageAction } from "actions/Dashboard";
import reactStringReplace from "react-string-replace";
import { IconInfoCircle, IconSearch } from "@tabler/icons-react";
import moment from "moment";

interface AccordionLabelProps {
    label: string;
    image: string;
    description: string;
}

function AccordionLabel({ label, image, description }: AccordionLabelProps) {
    return (
      <Group wrap="nowrap">
        {/* <Avatar radius="xl" size="lg">
            <IconRobot size={1} />
        </Avatar> */}
        <div>
          <Text>{label}</Text>
          <Text size="sm" c="dimmed" fw={400}>
            {description}
          </Text>
        </div>
      </Group>
    );
}

const regx = /(?=.)(.*)(?<=:)/gim;

const TriageDetails = () => {
    const [searchParams] = useSearchParams();
    const eventTitle = searchParams.get('eventTitle');
    const [selectedRows, setSelectedRows] = useState<number[]>([]);
    const [searchText, setSearchText] = useState<string>('');
    const [eventListDetails, setEventListDetails] = useState<any>();

    const [visible, handlers] = useDisclosure(false);

    // useEffect(() => {
    //     if(searchText) {
    //         handlers.open();
    //         const response = getTriageAction({ "new_item": searchText });
    //         response.then((result: any) => {
    //             setEventListDetails(result);
    //             handlers.close();
    //         });
    //     }
    // }, [searchText])

    const rowsDownstream = eventListDetails && eventListDetails.downstream && eventListDetails.downstream.length > 0 && eventListDetails.downstream.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['RELATION_LOGICAL_NAME']}</Table.Td>
            <Table.Td>{element['RELATION_NETWORK_NAME']}</Table.Td>
            <Table.Td>{element['PFZ_STATUS']}</Table.Td>
        </Table.Tr>
    ));

    const rowsNEvents = eventListDetails && eventListDetails.n_events && eventListDetails.n_events.length > 0 && eventListDetails.n_events.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['event_id']}</Table.Td>
            <Table.Td>{moment(element['created_time']).utc().format('MMMM DD YYYY, h:mm:ss A')}</Table.Td>
            <Table.Td>{element['responsible_service_area']}</Table.Td>
            <Table.Td>{element['event_title']}</Table.Td>
            <Table.Td>{element['config_item_id']}</Table.Td>
            <Table.Td>{element['network_name']}</Table.Td>
            <Table.Td>{element['description']}</Table.Td>
        </Table.Tr>
    ));

    const rowsIncidents = eventListDetails && eventListDetails.n_incidents && eventListDetails.n_incidents.length > 0 && eventListDetails.n_incidents.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['STATUS']}</Table.Td>
            <Table.Td>{moment(element['OPEN_TIME']).utc().format('MMMM DD YYYY, h:mm:ss A')}</Table.Td>
            <Table.Td>{element['NETWORK_NAME']}</Table.Td>
            <Table.Td>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
        </Table.Tr>
    ));

    const rowsRfc = eventListDetails && eventListDetails.n_rfc && eventListDetails.n_rfc.length > 0 && eventListDetails.n_rfc.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['STATUS']}</Table.Td>
            <Table.Td>{moment(element['OPEN_TIME']).utc().format('MMMM DD YYYY, h:mm:ss A')}</Table.Td>
            <Table.Td>{element['NETWORK_NAME']}</Table.Td>
            <Table.Td>{element['ASSIGN_DEPT']}</Table.Td>
            <Table.Td>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
        </Table.Tr>
    ));

    const rowsIcLocation = eventListDetails && eventListDetails.ic_location && eventListDetails.ic_location.length > 0 && eventListDetails.ic_location.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['STATUS']}</Table.Td>
            <Table.Td>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
        </Table.Tr>
    ));

    const rowsRfcLocation = eventListDetails && eventListDetails.rfc_location && eventListDetails.rfc_location.length > 0 && eventListDetails.rfc_location.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>{element['NUMBERPRGN']}</Table.Td>
            <Table.Td>{element['STATUS']}</Table.Td>
            <Table.Td>{element['ASSIGN_DEPT']}</Table.Td>
            <Table.Td>{element['BRIEF_DESCRIPTION']}</Table.Td>
            <Table.Td>{element['LOCATION']}</Table.Td>
        </Table.Tr>
    ));

    const handleEventSearch = () => {
        if(searchText) {
            handlers.open();
            const response = getTriageAction({ "new_item": searchText });
            response.then((result: any) => {
                setEventListDetails(result);
                handlers.close();
            });
        }
    }

    return (
        <StyleContainer fluid>
            <LoadingOverlay loaderProps={{ color: '#000484' }} visible={visible} zIndex={1000} overlayProps={{ radius: "sm", blur: 2, children: 'Loading, Waiting for vox response, it may take up to 1-2 minutes....' }} />
            <PageHeader title={'Triage Details'} subTitle={eventTitle} />
            <Paper className="paperTbl">
                <Group justify="center">
                    <Stack
                        align="stretch"
                        justify="center"
                        gap="0"
                    >
                        <Group justify="">
                            {/* <Button variant="default" className="aiBtn">
                                AI Results <Image
                                    className="aiIcon"
                                    src={Icons.Imgbot_white}
                                    onClick={() => { }}
                                />
                            </Button> */}
                            {/* <Text size="sm">
                                Search for triage details: 
                            </Text> */}
                        </Group>
                    </Stack>
                    <Group wrap="nowrap">
                        <Group justify="center">
                            <Input w={'500px'} placeholder="Enter CI/Application name to search for traige details" mr={'-20px'} onChange={(event: any) => setSearchText(event.currentTarget.value)} />
                            <Button onClick={() => { handleEventSearch() }}><IconSearch size={18} /></Button>
                        </Group>
                    </Group>
                </Group>
            </Paper>
            { eventListDetails && Object.keys(eventListDetails).length > 0 &&
            <Accordion chevronPosition="right" variant="contained" pt={10} defaultValue={'acc_triage_llm'}>
                <Accordion.Item value={'acc_triage_llm'}>
                    <Accordion.Control>
                        <AccordionLabel label='CI Information' image='' description="Basic Triage Details" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Paper className="paperTbl" style={{ textAlign: 'left' }}>
                            <ScrollArea h={350}>
                                {/* <Text fw={700}>GCC Notes:</Text> */}
                                <div style={{ whiteSpace: "pre-line" }}>
                                { eventListDetails && eventListDetails.traige_llm &&
                                    reactStringReplace(eventListDetails.traige_llm, regx, (match: any, i) => (
                                        <strong>
                                            {match}
                                        </strong>
                                    ))
                                }
                                </div>
                            </ScrollArea>
                        </Paper>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_downstream'}>
                    <Accordion.Control>
                        <AccordionLabel label='Downstream' image='' description="Downstream Relationships" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>RELATION_LOGICAL_NAME</Table.Th>
                                    <Table.Th>RELATION_NETWORK_NAME</Table.Th>
                                    <Table.Th>PFZ_STATUS</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsDownstream ? rowsDownstream : 'No Record Found.'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_n_events'}>
                    <Accordion.Control>
                        <AccordionLabel label='Events' image='' description="Events by network name" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>event_id</Table.Th>
                                    <Table.Th>created_time</Table.Th>
                                    <Table.Th>responsible_service_area</Table.Th>
                                    <Table.Th>event_title</Table.Th>
                                    <Table.Th>config_item_id</Table.Th>
                                    <Table.Th>network_name</Table.Th>
                                    <Table.Th>description</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsNEvents ? rowsNEvents : 'No record found'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_n_incidents'}>
                    <Accordion.Control>
                        <AccordionLabel label='Incidents' image='' description="Incidents by network name" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder stickyHeader withColumnBorders className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>NUMBERPRGN</Table.Th>
                                    <Table.Th>STATUS</Table.Th>
                                    <Table.Th>OPEN_TIME</Table.Th>
                                    <Table.Th>NETWORK_NAME</Table.Th>
                                    <Table.Th>BRIEF_DESCRIPTION</Table.Th>
                                    <Table.Th>LOCATION</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsIncidents ? rowsIncidents : 'No record found'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_n_rfc'}>
                    <Accordion.Control>
                        <AccordionLabel label='RFC' image='' description="Rfc by network name" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder withColumnBorders stickyHeader className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>NUMBERPRGN</Table.Th>
                                    <Table.Th>STATUS</Table.Th>
                                    <Table.Th>OPEN_TIME</Table.Th>
                                    <Table.Th>NETWORK_NAME</Table.Th>
                                    <Table.Th>ASSIGN_DEPT</Table.Th>
                                    <Table.Th>BRIEF_DESCRIPTION</Table.Th>
                                    <Table.Th>LOCATION</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsRfc ? rowsRfc : 'No record found'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
                <Accordion.Item value={'acc_location'}>
                    <Accordion.Control>
                        <AccordionLabel label='Location' image='' description="Incidents/rfcs by location" />
                    </Accordion.Control>
                    <Accordion.Panel>
                        <Stack
                            align="flex-start"
                            justify="center"
                            gap="0"
                        >
                        <Text size="sm" fw={700} td={'underline'}>
                            IC Location: 
                        </Text>
                        </Stack>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder withColumnBorders stickyHeader className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>NUMBERPRGN</Table.Th>
                                    <Table.Th>STATUS</Table.Th>
                                    <Table.Th>BRIEF_DESCRIPTION</Table.Th>
                                    <Table.Th>LOCATION</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsIcLocation ? rowsIcLocation : 'No record found'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                        <Stack
                            align="flex-start"
                            justify="center"
                            gap="0"
                        >
                            <Text size="sm" fw={700} td={'underline'}>
                                RFC Location: 
                            </Text>
                        </Stack>
                        <Table.ScrollContainer minWidth={500}>
                        <Table striped highlightOnHover withTableBorder withColumnBorders stickyHeader className="inctable" style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}>
                            <Table.Thead style={{position: 'static'}}>
                                <Table.Tr>
                                    <Table.Th>NUMBERPRGN</Table.Th>
                                    <Table.Th>STATUS</Table.Th>
                                    <Table.Th>ASSIGN_DEPT</Table.Th>
                                    <Table.Th>BRIEF_DESCRIPTION</Table.Th>
                                    <Table.Th>LOCATION</Table.Th>
                                </Table.Tr>
                            </Table.Thead>
                            <Table.Tbody>{rowsRfcLocation ? rowsRfcLocation : 'No record found'}</Table.Tbody>
                        </Table>
                        </Table.ScrollContainer>
                    </Accordion.Panel>
                </Accordion.Item>
            </Accordion>
            }
        </StyleContainer>
    )
}

export default TriageDetails;