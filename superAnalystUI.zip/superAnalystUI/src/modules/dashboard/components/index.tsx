import { useEffect, useState } from "react";
import { Group, Text, Stack, Anchor, Table, Paper, Image, LoadingOverlay, Tooltip, Pagination, Button, Input } from "@mantine/core"
import { useDisclosure } from '@mantine/hooks';
import { StyleContainer } from "../styles/Dashboard.styles"
import { Icons } from "assets/images"
import { CSVLink } from "react-csv";

import { useNavigate } from 'react-router-dom';
import PageHeader from "./PageHeader";
import { Route_URL } from "utils/constants/RouteURL";
import { getDashboardAction, getEventByIdAction, getEventDetailsAction, getIncidentAction } from "actions/Dashboard";
import { IconInfoCircle, IconPlus, IconSearch } from "@tabler/icons-react";
import { CONFIGURATIONS } from "utils/constants/configurations";
import moment from "moment";

const perPageLimit = 10;

const Dashboard = () => {
    const navigate = useNavigate()
    const [selectedRows, setSelectedRows] = useState<number[]>([]);
    const [currPage, setCurrPage] = useState<number>(1);
    const [eventDetails, setEventDetails] = useState<any>();
    const [incidentNum, setIncidentNum] = useState<string>('');
    const [listData, setListData] = useState<any>();
    const [visible, handlers] = useDisclosure(false);
    const [showPagination, setShowPagination] = useState<boolean>(false);

    useEffect(() => {
        handlers.open();
        const responseEvents = getDashboardAction({page: currPage, per_page: perPageLimit});
        responseEvents.then((result: any) => {
            setShowPagination(true);
            setEventDetails(result);
            handlers.close();
        });
    }, [currPage])

    const rowsEvents = eventDetails && eventDetails.length > 0 && eventDetails.map((element: any, index: number) => (
        <Table.Tr
            key={element.id}
            bg={selectedRows.includes(element.id) ? 'var(--mantine-color-blue-light)' : undefined}
            style={{textAlign: 'left'}}
        >
            <Table.Td>
                <Anchor href={`${CONFIGURATIONS.EVENT_LINK}${element.event_id}`} target="_blank">
                    GCC-{element.event_id}
                </Anchor>
            </Table.Td>
            <Table.Td>
                <Anchor href={`${Route_URL.incidentOverview}?eventId=${element.event_id}&eventTitle=${element.event_title}`} target="_blank">
                    {element.event_title}
                </Anchor>
            </Table.Td>
            <Table.Td>{element.severity}</Table.Td>
            <Table.Td>{moment(element.created_ts).utc().format('MMMM DD YYYY, h:mm:ss A')}</Table.Td>
        </Table.Tr>
    ));

    const handleEventSearch = () => {
        if(incidentNum === '') {
            handlers.open();
            const responseEvents = getDashboardAction({page: currPage, per_page: perPageLimit});
            responseEvents.then((result: any) => {
                setShowPagination(true);
                setEventDetails(result);
                handlers.close();
            });
            return;
        }
        handlers.open();
        const responseEvents = getEventByIdAction({id: incidentNum});
        responseEvents.then((result: any) => {
            if(result && result.status === 404) {
                handlers.close();
                setShowPagination(false);
                setEventDetails([]);
                return;
            }
            setShowPagination(false);
            setEventDetails([result]);
            handlers.close();
        });
    }

    return (
        <StyleContainer fluid>
            <LoadingOverlay loaderProps={{color: '#000484'}} visible={visible} zIndex={1000} overlayProps={{ radius: "sm", blur: 2 }} />
            <PageHeader />
            <Paper className="paperTbl">
                <Group justify="space-between">
                    <Stack
                        align="stretch"
                        justify="center"
                        gap="0"
                    >
                        <Text className="tableTitle">Events List</Text>
                        {/* <Text size="sm" className="tableSubTitle">Server Potential Issues</Text> */}
                    </Stack>
                    <Group wrap="nowrap" mb={10}>
                        {/* <Button type="button" variant="filled" rightSection={<IconPlus size={14} />} className="btnCreate" onClick={() => {}}>Create</Button> */}
                        <Group justify="center">
                            <Input placeholder="Search Event" mr={'-20px'} onChange={(event: any) => setIncidentNum(event.currentTarget.value)} />
                            <Button onClick={() => { handleEventSearch() }}><IconSearch size={18} /></Button>
                        </Group>
                        {/* <Select
                            label=""
                            w={140}
                            placeholder="Pick value"
                            data={['Last 30 Day', 'Last 3 Months', 'Last 6 Months', 'Last 1 Year']}
                            defaultValue="Last 30 Day"
                            allowDeselect={false}
                        />
                        <Select
                            label=""
                            w={140}
                            placeholder="Items per page"
                            data={['10', '20', '50', '100']}
                            defaultValue=""
                            clearable
                        />
                        <Select
                            label=""
                            w={140}
                            placeholder="Sort by"
                            data={['Network Id', 'Incident Type', 'Priority', 'Status']}
                            defaultValue=""
                            clearable
                        /> */}
                        {/* <Image
                            className=""
                            src={Icons.Imgicon_delete_sm}
                            onClick={() => { }}
                        /> */}
                        <CSVLink data={listData ?? ''} filename="device_overview">
                            <Image
                                src={Icons.Imgicon_dowload_sm}
                            />
                        </CSVLink>
                        {/* <Image
                            src={Icons.Imgicon_3_dots_options}
                            onClick={() => { }}
                        /> */}
                    </Group>
                </Group>
                <Table.ScrollContainer minWidth={500}>
                <Table striped highlightOnHover withTableBorder withColumnBorders className="inctable"
                    style={{whiteSpace: 'nowrap', display: 'inline-table', overflowY: 'hidden'}}
                >
                    <Table.Thead style={{position: 'static'}}>
                        <Table.Tr>
                            <Table.Th>Event Id</Table.Th>
                            <Table.Th>
                                Event Title
                                <Tooltip multiline w={220} withArrow color="rgb(54, 54, 54)" label="Click on the title to get co-related information of the event.">
                                    <IconInfoCircle size={20} />
                                </Tooltip>
                            </Table.Th>
                            <Table.Th>Severity</Table.Th>
                            <Table.Th>created_ts</Table.Th>
                        </Table.Tr>
                    </Table.Thead>
                    <Table.Tbody>{rowsEvents ? rowsEvents : 'No record found'}</Table.Tbody>
                </Table>
                </Table.ScrollContainer>
                { showPagination === true &&
                    <Pagination.Root total={3100/perPageLimit} pt={20} onChange={(value: number) => setCurrPage(value)}>
                        <Group gap={5} justify="center">
                            <Pagination.First />
                            <Pagination.Previous />
                            <Pagination.Items />
                            <Pagination.Next />
                            <Pagination.Last />
                        </Group>
                    </Pagination.Root>
                }
            </Paper>
        </StyleContainer>
    )
}

export default Dashboard