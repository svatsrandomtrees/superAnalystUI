import { useEffect, useState } from "react";
import { Accordion, Button, Group, Paper, ScrollArea, Text, Image, LoadingOverlay, Anchor } from "@mantine/core";
import { useDisclosure } from "@mantine/hooks";
import { notifications } from '@mantine/notifications';
import classes from '../../login/styles/AuthenticationImage.module.css';
import { Icons } from "assets/images";
import { getCoRelatedPlaybookAction } from "actions/Dashboard";
import { CONFIGURATIONS } from "utils/constants/configurations";
import reactStringReplace from "react-string-replace";

const regEventId = /\b\d{5}\b/g;

const CoRelationPlaybookDetails = () => {
    const [visible, handlers] = useDisclosure(false);
    const [playBookData, setPlayBookData] = useState<string>('');
    const [value, setValue] = useState<string | null>(null);

    useEffect(() => {
        return () => {
            setPlayBookData('');
        }
    }, [])

    useEffect(() => {
        if(value && playBookData === '') {
            handlers.open();
            const response = getCoRelatedPlaybookAction({});
            response.then((result: any) => {
                if(result) {
                    const re = /(?=.)(.*)(?<=:)/gim;
                    const allEventLinks = result.match(regEventId);
                    let respResult = result;
                    if(allEventLinks && allEventLinks.length > 0) {
                        allEventLinks.forEach((evLink: string) => {
                            respResult = reactStringReplace(respResult, evLink, (match, i) => (
                                <Anchor key={match + i} href={`${CONFIGURATIONS.EVENT_LINK}${match}`} underline="always" target="_blank">{match}</Anchor>
                            ));
                        })
                    }
                    const allRfcEventLinks = result.match(/CR\d\d{6}/g);
                    if(allRfcEventLinks && allRfcEventLinks.length > 0) {
                        allRfcEventLinks.forEach((evLink: string) => {
                            respResult = reactStringReplace(respResult, evLink, (match, i) => (
                                <Anchor key={match + i} href={`${CONFIGURATIONS.SMWEBRFC_LINK}${match}`} underline="always" target="_blank">{match}</Anchor>
                            ));
                        })
                    }
                    respResult = reactStringReplace(respResult, re, (match, i) => (
                        <strong>{match}</strong>
                    ));
                    setPlayBookData(respResult);
                    handlers.close();
                } else {
                    notifications.show({
                        color: 'red',
                        title: 'Error!!',
                        message: 'No record found, Please try again.',
                        classNames: classes,
                    })
                    handlers.close();
                }
            });
        }
    }, [value])

    return (
        <Paper className="incidentInfo">
            <LoadingOverlay loaderProps={{color: '#000484', children: 'Waiting for vox api response....'}} visible={visible} zIndex={1000} overlayProps={{ radius: "sm", blur: 2 }} />
            <Accordion variant="contained" pb={10} value={value} onChange={setValue}>
                <Accordion.Item value="aiResult">
                    <Accordion.Control bg={'#CFDFFF'}>
                        <Group justify="">
                            <Button variant="default" className="aiBtn">
                                CO Related Results <Image
                                    className="aiIcon"
                                    src={Icons.Imgbot_white}
                                    onClick={() => { }}
                                />
                            </Button>
                            <Text size="sm">
                                Click for related/similar Events playbook
                            </Text>
                        </Group>
                    </Accordion.Control>
                    <Accordion.Panel className="AiResultContent">
                        <ScrollArea h={200}>
                            {playBookData &&
                                <div style={{ whiteSpace: "pre-line" }}>
                                    {playBookData}
                                </div>
                            }
                        </ScrollArea>
                    </Accordion.Panel>
                </Accordion.Item>
            </Accordion>
        </Paper>
    )
}

export default CoRelationPlaybookDetails;