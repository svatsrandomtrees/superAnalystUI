import styled from '@emotion/styled'
import { closeAllModals, openModal } from '@mantine/modals'
import { ErrorResponse } from 'App'
import Button from 'ui/buttons/Button'
import { dangerColor, monochromeColor, primaryColor } from 'utils/constants/ColorPalette'
import { fontFamily, fontStyle } from 'utils/constants/TypographyProperties'

const StyleModal = {
  height: 'fit-content',
  width: '100%',
  background: monochromeColor[6],
  boxShadow: '0px 6px 20px rgba(0, 0, 0, 0.1)',
  borderRadius: '4px',
}
const StyleTitle = {
  fontFamily: fontFamily,
  fontStyle: fontStyle,
  fontWeight: 700,
}
const StyleBody = {
  fontFamily: fontFamily,
  fontStyle: fontStyle,
  fontSize: '1rem',
  lineHeight: '1.1875rem',
  color: monochromeColor[2],
}
const StyleClose = {
  top: '14px',
  right: '16px',
}
export const errorModal = (error: unknown) => {
  const errorCode = (error as ErrorResponse).response.data.statusCode ?? ''
  const errorMessage =
    (error as ErrorResponse).response.data.errorMessage ?? 'Something Went Wrong.'

  return openModal({
    title: `Error ${errorCode && `- (${errorCode})`}`,
    centered: true,
    children: errorMessage,
    styles: {
      // modal: {
      //   ...StyleModal,
      //   maxWidth: 'calc(596px - 67px)',
      //   minHeight: 'calc(194px - 10px)',
      //   padding: '5px 12px 5px 45px',
      //   position: 'relative',
      // },
      title: {
        ...StyleTitle,
        fontSize: '1.5625rem',
        lineHeight: '1.875rem',
        textAlign: 'left',
        color: dangerColor,
        marginTop: '32px',
      },
      body: {
        ...StyleBody,
        fontWeight: 400,
        marginTop: '5px',
      },
      close: { ...StyleClose, position: 'absolute' },
    },
  })
}

const StyleButtonWrapper = styled.div`
  display: flex;
  justify-content: flex-end;
  margin-top: 29.75px;
  margin-right: 19px;
`
export const successModal = (message: string) => {
  return openModal({
    title: `Success!`,
    centered: true,
    children: (
      <>
        {message}
        <StyleButtonWrapper>
          <Button
            width='150px'
            buttonVariant='filled'
            onClick={closeAllModals}>
            Close
          </Button>
        </StyleButtonWrapper>
      </>
    ),
    styles: {
      // modal: {
      //   ...StyleModal,
      //   maxWidth: 'calc(685.004px - 67px)',
      //   minHeight: 'calc(310px - 10px)',
      //   padding: '5px 12px 36px 12px',
      //   position: 'relative',
      // },
      title: {
        ...StyleTitle,
        fontSize: '3.125rem',
        lineHeight: '3.8125rem',
        textAlign: 'center',
        display: 'flex',
        justifyContent: 'center',
        color: primaryColor,
        marginTop: '63.75px',
        marginRight: 0,
        width: '100%',
      },
      body: {
        ...StyleBody,
        fontWeight: 700,
        margin: '5px auto 0px auto',
        width: '100%',
        textAlign: 'center',
      },
      close: { ...StyleClose, position: 'absolute' },
    },
  })
}
