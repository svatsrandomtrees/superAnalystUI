
import axiosInstance from "./AxiosInstance";

export const loginService = async (payload: any) => {
    const response = await axiosInstance.get(`login`, { params: payload });
    return response;
};