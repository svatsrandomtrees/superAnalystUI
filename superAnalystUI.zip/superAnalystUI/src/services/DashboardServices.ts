import axiosInstance from "./AxiosInstance";
import axiosInstanceTriage from "./AxiosInstanceTriage";


export const getIncidentService = async (payload: any) => {
    const response = await axiosInstance.get(`input_network_details?limit=5`, { params: payload });
    return response;
};

export const getIncidentInfoService = async (payload: any) => {
    const response = await axiosInstance.post(`get_response`, payload);
    return response;
};

export const getEventDetailsService = async (payload: any) => {
    const response = await axiosInstance.get(`event_details?limit=5`, { params: payload });
    return response;
};

export const getIncidentsDetailsService = async (payload: any) => {
    const response = await axiosInstance.get(`incidents_details?limit=5`, { params: payload });
    return response;
};

export const getRfcDetailsService = async (payload: any) => {
    const response = await axiosInstance.get(`rfc_details?limit=5`, { params: payload });
    return response;
};

export const getCoRelatedService = async (payload: any) => {
    const response = await axiosInstance.post(`co_related`, payload);
    return response;
};

export const getCoRelatedPlaybookService = async (payload: any) => {
    const response = await axiosInstance.get(`co_related_playbook/`, payload);
    return response;
};

export const getDashboardService = async (payload: any) => {
    const response = await axiosInstance.get(`dashboard`, { params: payload });
    return response;
};

export const getRelatedServices = async (payload: any) => {
    const response = await axiosInstance.get(`api/`, { params: payload });
    return response;
};

export const getEventByIdService = async (payload: any) => {
    const response = await axiosInstance.get(`get_event_byid`, { params: payload });
    return response;
};

export const getTriageServices = async (payload: any) => {
    const response = await axiosInstanceTriage.post(`traige?new_item=${payload.new_item}`, payload );
    return response;
};