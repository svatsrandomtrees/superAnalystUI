import React, { ReactNode, useState } from 'react'
import { AppShell, Burger, Group, Skeleton, Code, Avatar, Badge, Container, Image } from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import styled from '@emotion/styled'
import { FooterScreen } from './common/FooterScreen'
import HeaderScreen from './common/HeaderScreen';
import SideBarScreen from './common/SideBarScreen';

const StyleFooterPositionWrapper = styled.div`
  position: sticky;
  bottom: auto;
  width: 100%;
  z-index: 10;
`
const ContentContainerWrapper = styled.div`
  max-width: 100%;
  flex: 1;
`
const PrivateLayoutWrapper = styled.div`
  overflow: hidden;
`
const ContentContainer = styled.div`
  max-width: 100%;
  width: 100%;
`
interface PrivateLayoutProps {
  children: ReactNode
}

const PrivateLayout: React.FC<PrivateLayoutProps> = ({
  children
}) => {
  const [opened, { toggle }] = useDisclosure();

  return (
    <AppShell
      layout="alt"
      header={{ height: 60 }}
      navbar={{ width: 250, breakpoint: 'sm', collapsed: { mobile: !opened } }}
      padding="md"
    >
      <AppShell.Header>
        <HeaderScreen opened={opened} toggle={toggle} />
      </AppShell.Header>
      <AppShell.Navbar>
        {/* <Burger opened={opened} onClick={toggle} size="sm" m={20} /> */}
        <SideBarScreen />
      </AppShell.Navbar>
      <AppShell.Main>
        <ContentContainer>{children}</ContentContainer>
      </AppShell.Main>
    </AppShell>
  )
}

export default PrivateLayout
