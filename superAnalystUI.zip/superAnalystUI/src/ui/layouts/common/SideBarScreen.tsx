import React, { useState } from 'react'
import { Group, Avatar, Image, CardSection, Indicator } from '@mantine/core';

import { Icons } from 'assets/images';
import classes from './SideNavbar.module.css';
import LinksGroup from './NavbarLinksGroup/NavbarLinksGroup';
import { Route_URL } from 'utils/constants/RouteURL';
import sidebarIcon1 from '../../../assets/images/object_asset_small_01.png'
import sidebarIcon2 from '../../../assets/images/object_asset_small_02.png'
import sidebarIcon3 from '../../../assets/images/object_asset_small_03.png'
import sidebarIcon4 from '../../../assets/images/object_asset_small_04.png'


const sideMenuData = [
    {
        label: 'Dashboard',
        icon: 'Imgicon_dashboard_sm',
        initiallyOpened: true,
        links: [
            // { label: 'New Incidents', icon: 'Imgicon_new_incidents_sm', link: Route_URL.dashboard },
            { label: 'My Events', icon: 'Imgicon_statement', link: '/' },
            { label: 'Triage Details', icon: 'Imgicon_history_sm', link: Route_URL.triageDetails }
        ],
    },
    // {
    //     label: 'Insights',
    //     icon: 'Imgicon_dashboard_sm',
    //     initiallyOpened: false,
    //     links: [
    //         { label: 'Inbox', icon: 'Imgicon_inbox_sm', notifications: 0, link: '/' },
    //         { label: 'Notifications', icon: 'Imgicon_notification_sm', notifications: 0, link: '/' },
    //         { label: 'Chat', icon: 'Imgicon_chat_sm', notifications: 0, link: '/' }
    //     ],
    // },
];

const SideBarScreen = () => {
    const [active, setActive] = useState('Dashboard');
    const links = sideMenuData.map((item) => <LinksGroup active={active} setActive={(val: string) => setActive(val)} {...item} key={item.label} />);

    return (
        <div className={classes.sideNav}>
            <Image
                // visibleFrom={"md"}
                radius="md"
                fit="contain"
                w={'230px'}
                src={Icons.ImgLogoSuperAnalystBg}
            />
            <nav className={classes.navbar}>
                <div className={classes.navbarMain}>
                    {/* <Group className={classes.header}>
                        <Indicator inline processing color="#6149CD" size={12} disabled={false}><Avatar variant="filled" radius="sm" src="" color='grape' /></Indicator>
                        <a href="#" className={classes.link} onClick={(event) => event.preventDefault()}>
                            <span>My Profile Settings</span>
                        </a>
                        <Image
                            p={'5px'}
                            src={Icons.Imgicon_arrow_small}
                        />
                    </Group> */}
                    {links}
                </div>

                {/* <div className={classes.footer}>
            <a href="#" className={classes.link} onClick={(event) => event.preventDefault()}>
              <IconSwitchHorizontal className={classes.linkIcon} stroke={1.5} />
              <span>Change account</span>
            </a>

            <a href="#" className={classes.link} onClick={(event) => event.preventDefault()}>
              <IconLogout className={classes.linkIcon} stroke={1.5} />
              <span>Logout</span>
            </a>
          </div> */}
            </nav>
        </div>
    )
}

export default SideBarScreen