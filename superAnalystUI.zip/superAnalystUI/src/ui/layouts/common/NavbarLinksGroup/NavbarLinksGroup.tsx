import { useState } from 'react';
import { Group, Box, Collapse, ThemeIcon, Text, UnstyledButton, rem, Image } from '@mantine/core';
import { IconCalendarStats, IconChevronRight } from '@tabler/icons-react';
import { useNavigate } from 'react-router-dom';
import classes from './NavbarLinksGroup.module.css';
import { Icons } from 'assets/images';

interface LinksGroupProps {
  icon: any;
  label: string;
  initiallyOpened?: boolean;
  links?: { label: string; link: string, icon: string }[];
  active: string,
  setActive: any
}

const LinksGroup = ({ icon, label, initiallyOpened, links, active, setActive }: LinksGroupProps) => {
  const navigate = useNavigate()
  const hasLinks = Array.isArray(links);
  const [opened, setOpened] = useState(initiallyOpened || false);
  const items = (hasLinks ? links : []).map((link) => (
    <>
    <Text<'a'>
      component="a"
      className={classes.link}
      href={link.link}
      key={link.label}
      data-active={link.label === active || undefined}
      onClick={(event) => {
        event.preventDefault();
        setActive(link.label);
        navigate(link.link);
      }}
    >
      <Image
          p={'10px'}
          src={Icons[link.icon]}
      />
      {link.label}
    </Text>
    </>
  ));

  return (
    <>
      <UnstyledButton onClick={() => setOpened((o) => !o)} className={classes.control}>
        <Group justify="space-between" gap={0} style={{
            background: '#363636 0% 0% no-repeat padding-box',
            opacity: 1,
            padding: '0 10px 0 10px'
          }}>
          <Box style={{ display: 'flex', alignItems: 'center' }}>
            <Image
                p={'10px'}
                src={Icons[icon]}
            />
            <Box ml="md">{label}</Box>
          </Box>
          {hasLinks && (
            <IconChevronRight
              className={classes.chevron}
              stroke={1.5}
              style={{
                width: rem(16),
                height: rem(16),
                transform: opened ? 'rotate(-90deg)' : 'none',
              }}
            />
          )}
        </Group>
      </UnstyledButton>
      {hasLinks ? <Collapse in={opened}>{items}</Collapse> : null}
    </>
  );
}

export default LinksGroup;

// const mockdata = {
//   label: 'Releases',
//   icon: IconCalendarStats,
//   links: [
//     { label: 'Upcoming releases', link: '/', icon: '' },
//     { label: 'Previous releases', link: '/' },
//     { label: 'Releases schedule', link: '/' },
//   ],
// };

// export function NavbarLinksGroup() {
//   return (
//     <Box mih={220} p="md">
//       <LinksGroup {...mockdata} />
//     </Box>
//   );
// }