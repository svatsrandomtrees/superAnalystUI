interface FooterLinksProps {}

export function FooterScreen({}: FooterLinksProps) {

  return (
    <>
      <footer>
      </footer>
    </>
  )
}
