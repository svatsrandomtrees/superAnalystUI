import {
  Group,
  Box,
  Burger,
  Image,
  Paper
} from '@mantine/core';
import { useNavigate, useLocation } from 'react-router-dom';
import classes from './HeaderMegaMenu.module.css';
import { Icons } from 'assets/images';
import { Route_URL } from 'utils/constants/RouteURL';

const HeaderScreen = (props: any) => {
  const navigate = useNavigate()
  const location = useLocation();
  const { opened, toggle } = props;
console.log(location, 'location');
  const handleLogout = () => {
    localStorage.clear();
    navigate(Route_URL.login)
  }
  
  return (
    <Box>
      <header className={classes.header}>
        <Burger opened={opened} onClick={toggle} hiddenFrom="sm" size="sm" />
        <Group justify="space-between" h="100%">
          <Group visibleFrom="sm">
            <a href="#" className={classes.link}>
            {location.pathname === '/dashboard/triage_details' ? 'Triage Management' : 'Events Management'}
            </a>
          </Group>
          <Group visibleFrom="sm">
            {/* <Paper shadow="xs" p="sm">
            <Image
              className={classes.pointer}
              src={Icons.Imgion_chat_communication_sm}
              onClick={() => {}}
            />
            </Paper>
            <Image
              className={classes.pointer}
              src={Icons.Imgicon_notifications_top_sm}
              onClick={() => {}}
            />
            <Image
              className={classes.pointer}
              src={Icons.Imgicon_apps_option_top_sm}
              onClick={() => {}}
            />
            <Image
              className={classes.pointer}
              src={Icons.Imgicon_activities_top_sm}
              onClick={() => {}}
            />
            <Image
              className={classes.pointer}
              src={Icons.Imgicon_settings_top_sm}
              onClick={() => {}}
            /> */}
            <Image
              className={classes.pointer}
              src={Icons.Imgicon_top_log_out_sm}
              onClick={() => {handleLogout()}}
            />
          </Group>
        </Group>
      </header>
    </Box>
  );
}

export default HeaderScreen;