import { getCoRelatedPlaybookService, getCoRelatedService, getDashboardService, getEventByIdService, getEventDetailsService, getIncidentInfoService, getIncidentService, getIncidentsDetailsService, getRelatedServices, getRfcDetailsService, getTriageServices } from "services/DashboardServices";

export const getIncidentAction = async (payload: any) => {
    return await getIncidentService(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const getIncidentInfoAction = async (payload: any) => {
    // return {
    //     "triage_response": "For triaging the incident related to CI4110113, critical details include:\n\n1. Logical Name: pfz_bus_critical\n2. Network Name: TOL-2-1-MA-SWS-01\n3. Time Zone: America/Mexico_City\n4. Site Primary Contact: ALVA, CARLOS ALBERTO\n5. Corporate Structure: PGS\n\nThese details will assist in assessing the situation, determining the impact, and deciding on the priority for resolution. Reach out to the primary contact, CARLOS ALBERTO ALVA, for further information about the incident and to discuss the next steps in the resolution process.",
    //     "playbook": "Playbook:\n\nI. Overview\n\n   Event ID: 49167\n   Event Title: Unreachability of Cisco network stackable switch at Toluca, Mexico\n   Category: Network - Data - LAN\n   Business Impact: No immediate impact reported. Toluca site in Mexico is a significant location, but operations remain unaffected at this moment.\n\nII. Root Cause:\n\n   The initial report indicated that the Cisco network stackable switch at Toluca, Mexico, was unreachable. However, subsequent checks showed that the switch was up and responding to ping requests. It is probable that a temporary network glitch caused the initial unreachability issue. \n\nIII. Incident Response & Resolution Steps\n\n1. A GCC Engineer was assigned to the incident (Reference Number DC1RN137975) with the responsibility to investigate and rectify the issue.\n\n2. The engineer conducted a ping test on the supposedly unreachable switch (TOL-2-1-MA-SWS-01) and received positive responses, indicating that the switch was up and reachable.\n\n3. Given the positive results from the ping test, the event was treated as passive as there was no identifiable impact, and the switch was functioning as expected.\n\n4. Status of the event was changed from 'Open' to 'Triage in Progress', indicating that the engineer had begun to investigate the issue.\n\n5. A potential new issue was created for the switch under the same reference number, indicating that a deeper investigation was initiated.\n\n6. The status of the event was changed from 'Triage in Progress' to 'Converted to GCC Event', symbolizing that the issue was recognized, resolved, and documented for future references.\n\nIV. Post-Incident Actions\n\nThe switch should be monitored closely to ensure continued functionality. If the switch becomes unreachable in the future, an in-depth investigation should be conducted to prevent the recurrence of the issue. \n\nPlease note that this playbook is subject to change based on new information or unfolding events."
    // }
    return await getIncidentInfoService(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const getEventDetailsAction = async (payload: any) => {
    return await getEventDetailsService(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const getIncidentsDetailsAction = async (payload: any) => {
    return await getIncidentsDetailsService(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const getRfcDetailsAction = async (payload: any) => {
    return await getRfcDetailsService(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const getCoRelatedAction = async (payload: any) => {
    return await getCoRelatedService(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const getCoRelatedPlaybookAction = async (payload: any) => {
    return await getCoRelatedPlaybookService(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const getDashboardAction = async (payload: any) => {
    return await getDashboardService(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const getRelatedAction = async (payload: any) => {
    return await getRelatedServices(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const getEventByIdAction = async (payload: any) => {
    return await getEventByIdService(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};

export const getTriageAction = async (payload: any) => {
    return await getTriageServices(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};