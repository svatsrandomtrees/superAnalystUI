import { loginService } from "services/AuthServices";

export const loginAction = async (payload: any) => {
    return await loginService(payload).then((result) => {
        return result.data;
    }).catch((error) => {
        return error.response;
    });
};