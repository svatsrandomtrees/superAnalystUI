import TriageDetails from 'modules/dashboard/components/TriageDetails'
import ErrorHandler from 'modules/error/ErrorHandler'
import { ErrorBoundary } from 'react-error-boundary'
import PrivateLayout from 'ui/layouts/PrivateLayout'

export default function TraigeDetailsScreen() {
  return (
    <PrivateLayout>
      <ErrorBoundary FallbackComponent={ErrorHandler}>
        <TriageDetails />
      </ErrorBoundary>
    </PrivateLayout>
  )
}
