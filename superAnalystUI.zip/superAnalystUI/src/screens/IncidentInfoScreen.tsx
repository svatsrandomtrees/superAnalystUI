import IncidentOverview from 'modules/dashboard/components/IncidentOverview'
import ErrorHandler from 'modules/error/ErrorHandler'
import { ErrorBoundary } from 'react-error-boundary'
import PrivateLayout from 'ui/layouts/PrivateLayout'

export default function IncidentOverviewScreen() {
  return (
    <PrivateLayout>
      <ErrorBoundary FallbackComponent={ErrorHandler}>
        <IncidentOverview />
      </ErrorBoundary>
    </PrivateLayout>
  )
}
