import ErrorHandler from 'modules/error/ErrorHandler'
import Login from 'modules/login/components'
import { ErrorBoundary } from 'react-error-boundary'
import PublicLayout from 'ui/layouts/PublicLayout'

export default function LoginScreen() {
  return (
    <PublicLayout>
      <ErrorBoundary FallbackComponent={ErrorHandler}>
        <Login />
      </ErrorBoundary>
    </PublicLayout>
  )
}
