import PublicLayout from 'ui/layouts/PublicLayout'
import { StyleModalBox } from 'modules/login/styles/Login.styles'
import styled from '@emotion/styled'
import { useMantineTheme } from '@mantine/core'
import { ThemeInterface, monochromeColor } from 'utils/constants/ColorPalette'
import { fontFamily, fontStyle } from 'utils/constants/TypographyProperties'

const UnauthorizedText = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  font-family: ${fontFamily};
  font-style: ${fontStyle};
  font-weight: 700;
  font-size: 1.4375rem;
  line-height: 2rem;
  color: ${monochromeColor[0]};
  height: 100%;
`

const UnauthorizedScreen = () => {
  const theme = useMantineTheme()

  return (
    <PublicLayout>
      <StyleModalBox
        style={{
          height: '200px',
          borderRadius: '10px',
          maxWidth: '500px',
          width: '100%',
          marginTop: 'auto',
          marginBottom: 'auto',
        }}>
        <UnauthorizedText>401 Unauthorized</UnauthorizedText>
      </StyleModalBox>
    </PublicLayout>
  )
}
export default UnauthorizedScreen
