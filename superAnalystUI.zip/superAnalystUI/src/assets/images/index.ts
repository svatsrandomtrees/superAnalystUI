import logo_pfizer_thumbnail from "./logo_pfizer_thumbnail.png";
import logo_super_analyst from "./logo_super_analyst.png";
import icon_credentials_small from "./icon_credentials_small.png"
import logo_super_analyst_bg from "./logo_gen_ai_event_mgmt.png";
import icon_dashboard_sm from "./icon_dashboard_sm.png";
import icon_new_incidents_sm from "./icon_new_incidents_sm.png";
import icon_statement from "./icon_statement.png";
import icon_history_sm from "./icon_history_sm.png";
import icon_inbox_sm from "./icon_inbox_sm.png";
import icon_notification_sm from "./icon_notification_sm.png";
import icon_chat_sm from "./icon_chat_sm.png";
import icon_arrow_small from "./icon_arrow_small.png";
import icon_top_log_out_sm from "./icon_top_log_out_sm.png";
import icon_settings_top_sm from "./icon_settings_top_sm.png";
import icon_activities_top_sm from "./icon_activities_top_sm.png";
import icon_apps_option_top_sm from "./icon_apps_option_top_sm.png";
import icon_notifications_top_sm from "./icon_notifications_top_sm.png";
import ion_chat_communication_sm from "./ion_chat_communication_sm.png";
import icon_delete_sm from "./icon_delete_sm.png";
import icon_dowload_sm from "./icon_dowload_sm.png";
import icon_3_dots_options from "./icon_3_dots_options.png";
import super_analyst_button_sm from "./super_analyst_button_sm.png";
import icon_bot_super_analyst_active_01 from "./icon_bot_super_analyst_active_01.png";
import bot_white from "./bot_white.png";
import objects_01 from "./objects_01.png";
import objects_02 from "./objects_02.png";
import objects_03 from "./objects_03.png";
import icon_print from "./icon_print.png";
import icon_dowload from "./icon_dowload.png"

export const Icons: any = {
    ImgLogoPfizer: logo_pfizer_thumbnail,
    ImgLogoSuperAnalyst: logo_super_analyst,
    ImgIconCredentialsSmall: icon_credentials_small,
    ImgLogoSuperAnalystBg: logo_super_analyst_bg,
    Imgicon_dashboard_sm: icon_dashboard_sm,
    Imgicon_new_incidents_sm: icon_new_incidents_sm,
    Imgicon_statement: icon_statement,
    Imgicon_history_sm: icon_history_sm,
    Imgicon_inbox_sm: icon_inbox_sm,
    Imgicon_notification_sm: icon_notification_sm,
    Imgicon_chat_sm: icon_chat_sm,
    Imgicon_arrow_small: icon_arrow_small,
    Imgicon_top_log_out_sm: icon_top_log_out_sm,
    Imgicon_settings_top_sm: icon_settings_top_sm,
    Imgicon_activities_top_sm: icon_activities_top_sm,
    Imgicon_apps_option_top_sm: icon_apps_option_top_sm,
    Imgicon_notifications_top_sm: icon_notifications_top_sm,
    Imgion_chat_communication_sm: ion_chat_communication_sm,
    Imgicon_delete_sm: icon_delete_sm,
    Imgicon_dowload_sm: icon_dowload_sm,
    Imgicon_3_dots_options: icon_3_dots_options,
    Imgsuper_analyst_button_sm: super_analyst_button_sm,
    Imgicon_bot_super_analyst_active_01: icon_bot_super_analyst_active_01,
    Imgbot_white: bot_white,
    Imgobjects_01: objects_01,
    Imgobjects_02: objects_02,
    Imgobjects_03: objects_03,
    Imgicon_print: icon_print,
    Imgicon_dowload: icon_dowload
}